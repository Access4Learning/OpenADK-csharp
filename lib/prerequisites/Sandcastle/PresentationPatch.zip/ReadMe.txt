This is not an official patch from Microsoft so use at your own risk.

The following problems are fixed by the files in this archive:

1. Adding a root namespace page causes BuildAssembler to crash.

2. Presentation Style Issues:
   VS2005 style:
    A. The span.nolink style is missing the "font-weight: bold;" option.

    B. In the VS2005 style's presentation.css file, the "div.code pre"
       definition contains "word-wrap: break-word;" which causes word
       wrapping in the code blocks.  This is undesired behavior and it
       should be removed.

   Prototype style:
    A. <item id="XAMLLabel">XAML</item> is missing from the shared_content.xml
       file.

   All three presentation styles:
    A. Support for the href attribute should be added to the <see> tag to
       match the support for the href attribute on the <seealso> tag.
       Add this after the "see[@cref]" template in each style's
       main_sandcastle.xsl.

    B. Add "map" and "area" to the HTML passthrough tags so that image maps
       can appear in the comments.

3. Version Builder Issues:
    A. In the Prototype style, version information does not show up on the
       individual member pages.  Change the 'member' reference in the
       "<!-- versions -->" section in main_sandcastle.xsl to 'list' to fix it.

    B. The VS2005 style shows a Frameworks filter on all list style pages but
       the Hana and Prototype styles do not.  However, the VS2005 Frameworks
       filter does not work because the transforms use hard-coded filter names
       based on the Microsoft frameworks.  As such, the filter should be fixed
       so that it uses the user's filter names from the <versions> section of
       the reflection information. It should also appear in all three styles.

4. Script# Presentation Style Issues
   Add the following items to Presentation\Shared\content\syntax_content.xml:

   <item id="UnsupportedUnsafe_JavaScript">JavaScript does not support APIs that consume or return unsafe types.</item>
   <item id="UnsupportedGeneric_JavaScript">JavaScript does not support generic types or methods.</item>
   <item id="UnsupportedExplicit_JavaScript">JavaScript does not support explicit interface implementations.</item>
   <item id="UnsupportedOperator_JavaScript">JavaScript does not support overloaded operators.</item>
   <item id="UnsupportedStructure_JavaScript">JavaScript supports the use of structures, but not the declaration of new ones.</item>
   <item id="UnsupportedCast_JavaScript">JavaScript does not support the declaration of new casting operators.</item>

   Note that even when defined, the UnsupportedCast_JavaScript message does
   not appear.  It just shows the "JavaScript" title over a blank syntax
   section.

   Add <item id="JavaScriptLabel">JavaScript</item> to the shared_content.xml
   file for the Hana and Prototype styles.

   The style attribute of the JavaScript language element in the
   TransformComponent entry in all three VS2005 configuration files should
   be set to "cs" to match the other C-style languages:
   <language label="JavaScript" name="JavaScript" style="cs" />

Problems not fixed by this patch
--------------------------------
1. Hana style:
    A. The Hana style does not display the "Class" label after the class name
       in the auto-generated See Also section on the Events, Fields, Methods,
       and Properties list pages.

2. For the VS2005 and Hana styles, Overloads pages are being created for
   methods in base classes that do not have overridden methods in the
   documented class.  These are also appearing in the TOC.  For example, a
   System.Windows.Forms.Form derived class shows a number of overload list
   pages for methods from the base Form class.  These should not exist.

3. Version Builder Issues:
    A. The VS2005 style shows a Frameworks filter on all list style pages but
       the Hana and Prototype styles do not.  However, the VS2005 Frameworks
       filter does not work because the transforms use hard-coded filter names
       based on the Microsoft frameworks.  As such, the filter should be fixed
       so that it uses the user's filter names from the <versions> section of
       the reflection information. It should also appear in all three styles.

Eric Woodruff
Eric@EWoodruff.us
